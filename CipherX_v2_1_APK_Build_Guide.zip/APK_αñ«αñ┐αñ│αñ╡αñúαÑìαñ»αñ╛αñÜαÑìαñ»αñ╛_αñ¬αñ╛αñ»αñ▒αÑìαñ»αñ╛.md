# CipherX v2 — APK कसा मिळवायचा (कोडिंग नको)

## 1. GitHub वर अपलोड करा
1. github.com वर लॉगिन करा → वर उजवीकडे **+ → New repository**.
2. नाव: `CipherX`, **Private** निवडा → **Create repository**.
3. **uploading an existing file** या लिंकवर क्लिक करा.
4. ही zip फाइल आधी फोन/PC वर **Extract** करा. आतील **सर्व फाइल आणि फोल्डर** (app, gradle, .github, gradlew, build.gradle.kts …) ड्रॅग करून टाका.
   - महत्त्वाचे: `.github` हा लपलेला फोल्डर आहे. तो दिसत नसेल तर PC वर "Show hidden files" चालू करा. हा फोल्डर नसेल तर APK आपोआप बनणार नाही.
5. खाली **Commit changes** दाबा.

## 2. APK बनेल (3-4 मिनिटे)
1. वरच्या **Actions** टॅबवर जा → "Build APK" चालू असेल.
2. हिरवा बरोबरचा खूण आला की त्यावर क्लिक करा.
3. खाली **Artifacts** मध्ये **CipherX-debug-apk** डाउनलोड करा → unzip → `app-debug.apk`.
4. फोनवर पाठवा आणि इन्स्टॉल करा ("Install unknown apps" परवानगी द्या).

## 3. लाल ✗ आला तर
Actions मध्ये त्या रनवर क्लिक करा → लाल पायरीवर क्लिक करा → खालचा एरर मजकूर कॉपी करून मला पाठवा. मी दुरुस्त करतो.

## 4. ऍपमध्ये पहिल्यांदा
**Models** टॅब → Google Gemini कार्डमध्ये API key टाका (मोफत: aistudio.google.com/apikey) → **Save & test** → **Chat** टॅबवर प्रश्न विचारा.
