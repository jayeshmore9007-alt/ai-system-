# CipherX API starter reference

All `/api/*` routes require `Authorization: Bearer <CIPHERX_API_TOKEN>`.

## GET /health

Returns `{ "status": "ok", "service": "cipherx-api", "timestamp": "..." }`.

## GET /api/agents

Returns the agent catalogue. Statuses are `live`, `planned`, and `not_configured`; these describe the starter's actual implementation boundary, not external connectivity.

## POST /api/chat

Request:

```json
{
  "messages": [
    { "role": "user", "content": "Explain my network status" }
  ]
}
```

Optional `model` selects a model from the configured provider. The backend enforces message count and content-size limits. The provider base URL, model, and API key are server-side environment settings. This endpoint currently supports non-streaming OpenAI-compatible chat completions only.
