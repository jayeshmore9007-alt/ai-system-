# CIPHERX AI — implementation architecture

## Current baseline (from the supplied v2 archive)

The supplied project is a native Android app (Kotlin + Jetpack Compose), not a React Native/Expo app. It already contains a streaming chat client, configurable Gemini/OpenAI-compatible providers (including Groq, DeepSeek, Mistral and custom endpoints), on-device conversation persistence, speech-recognition intent input, Android TextToSpeech, and encrypted-preference API-key storage when Android Keystore support is available. The Android client currently calls providers directly using user-supplied keys.

## Architecture decision

Keep the native Android foundation for the current upgrade to avoid rewriting functioning chat/settings/history code. Introduce a separately deployable Node.js/Express backend as an optional secure gateway. The app's existing direct-provider mode remains available until a backend URL/token configuration UI and client are implemented. Do not put provider credentials in the APK.

```text
Android (Compose)
  ├─ Dashboard / Chat / Models / History / Settings / Agent catalogue
  ├─ ChatViewModel
  ├─ AiGateway (current direct BYO-key provider integration)
  ├─ SettingsStore (Android Keystore encrypted preferences when available)
  └─ Future platform adapters: Wi-Fi, USB OTG, BLE, speech
             │ HTTPS + bearer app token (backend integration pending)
             ▼
Node.js / Express API
  ├─ Authentication middleware
  ├─ Agent catalogue endpoint
  ├─ AI gateway endpoint (server-side provider key)
  ├─ Future: device adapters, workflow runner, audit, file service
  └─ Health endpoint
```

## Agent execution policy

The mobile app now includes a capability catalogue. LIVE means a concrete capability exists in the supplied app; PLANNED means it is not implemented; NOT CONFIGURED means an external credential, service, or hardware adapter is required. A catalogue entry is not an autonomous process. No shell executor, network attack, account scraping, or unrestricted device control is provided.

## Planned module boundaries

| Module | Responsibility | Current state |
|---|---|---|
| CIPHER CORE | Existing provider-backed chat UI | LIVE |
| VOICE AGENT | Android speech intent + TextToSpeech | LIVE, device language support varies |
| WIFI SENTINEL | Android connectivity and permission-aware diagnostics | PLANNED |
| DEVICE SCANNER | User-authorized discovery | PLANNED |
| FLIPPER AGENT | Supported USB/BLE device adapter | NOT CONFIGURED |
| ESP32 AGENT | Allowlisted BLE/Wi-Fi/USB serial protocol | NOT CONFIGURED |
| PAGER-X AGENT | Authenticated read-only backend adapter | NOT CONFIGURED |
| INSTAGRAM AGENT | Official Meta APIs and consent scopes | NOT CONFIGURED |
| APK BUILDER | CI/EAS build service integration | NOT CONFIGURED |
| AUTOMATION AGENT | Approval-gated workflow engine | PLANNED |
| SECURITY GUARD | Permission model and audit events | PLANNED |

## Backend API (starter)

- `GET /health` — public liveness endpoint; no provider credentials returned.
- `GET /api/agents` — bearer-token protected capability catalogue.
- `POST /api/chat` — bearer-token protected OpenAI-compatible chat proxy. Provider key remains server-side. The route currently returns a single completed response (not streaming).

Set environment variables from `backend/.env.example`. Generate `CIPHERX_API_TOKEN` with at least 32 random characters. Deploy behind HTTPS. Use a secret manager in production; `.env` is for local development only. Add rate limiting, persistent audit logging, user identity, token rotation, and request quotas before exposing publicly.

## Security boundaries

- Never embed provider secrets in source code or APK resources.
- Never implement unrestricted shell execution. Pager remediation must use explicit allowlisted operations.
- Hardware commands must be protocol-specific and user-approved.
- Instagram features must use official Meta APIs and granted permissions.
- Show DISCONNECTED / NOT CONFIGURED / SIMULATION accurately; never fabricate telemetry.
- Android Wi-Fi metadata access depends on OS version, target SDK, permissions, location services and device vendor behavior.
