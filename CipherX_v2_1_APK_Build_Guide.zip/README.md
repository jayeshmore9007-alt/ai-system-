# CipherX - AI Android App

A working Android AI chat app built with **Kotlin + Jetpack Compose + Google Gemini**.
Open the folder in Android Studio, add one API key, press Run. That is it.

---

## What you need

1. **Android Studio** (Ladybug or newer) - https://developer.android.com/studio
2. **A free Gemini API key** - https://aistudio.google.com/apikey
   (Google account required. The free tier is enough for testing.)
3. An Android phone (Android 7.0+) or the emulator.

## Run it

1. Unzip this folder somewhere permanent.
2. Android Studio -> **File > Open** -> pick the `CipherX` folder -> wait for Gradle sync.
   (First sync downloads Gradle and dependencies; it needs internet and takes a few minutes.)
3. Connect your phone with USB debugging on, or start an emulator.
4. Press the green **Run** button.
5. In the app, tap **Key** in the top bar, paste your Gemini API key, tap **Save**.
6. Ask something.

The key is never in the source code - it is stored in the app's private storage on the
device. That is why this project is safe to share or push to GitHub.

## Build an installable APK

In Android Studio: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The file appears in `app/build/outputs/apk/debug/`.

For a signed release build: **Build > Generate Signed Bundle / APK**, create a keystore,
choose `release`. Keep that keystore file safe - you need the same one for every future
update on Play Store.

## How the code is organised

| File | What it does |
|---|---|
| `MainActivity.kt` | Entry point, hosts the Compose UI |
| `ChatScreen.kt` | All the UI: chat list, input bar, settings dialog |
| `ChatViewModel.kt` | Holds chat state, calls the AI, handles errors |
| `GeminiClient.kt` | The only place that talks to Google's API |
| `ApiKeyStore.kt` | Saves the API key in private app storage |
| `ChatMessage.kt` | One message in the conversation |

## Changing things

- **App name / colours:** `app/src/main/res/values/strings.xml` for the name;
  wrap `MaterialTheme` in `MainActivity.kt` with your own `colorScheme`.
- **AI model:** `MODEL` constant in `GeminiClient.kt`.
  `gemini-2.5-flash` is fast and cheap. `gemini-2.5-pro` is smarter and slower.
  If you switch to `gemini-2.0-flash`, delete the `thinkingConfig` block.
- **AI behaviour:** the `SYSTEM_PROMPT` constant in `GeminiClient.kt`.
  This is where you turn it into a tutor, a code helper, a travel guide, and so on.
- **Speed / creativity:** `temperature` and `maxOutputTokens` in `GeminiClient.kt`.

## Adding more AI features later

The `GeminiClient` class is the seam. Add a method for each new capability:

- **Image understanding** - add an `inlineData` part with base64 JPEG bytes to the request.
  Take the photo with `ActivityResultContracts.TakePicturePreview`.
- **Voice** - Android's built-in `SpeechRecognizer` for input,
  `TextToSpeech` for reading replies out.
- **Streaming replies** - use the `:streamGenerateContent` endpoint and read the
  response body as a stream so text appears word by word.
- **Saving chats** - Room database (`androidx.room`) over `ChatMessage`.

## Important before you publish on Play Store

- **Do not ship your own API key inside the APK.** Anyone can extract it and spend your
  quota. Right now the user brings their own key, which is safe. If you want users to not
  need a key, put a small backend (Cloud Run / Firebase Functions) in between and let the
  app call that instead.
- **Privacy policy is mandatory** if your app sends user text to a third-party AI service.
  Disclose it plainly in the Play Store listing.
- **Data safety form:** declare that message text leaves the device.
- **App name:** names that suggest hacking, bypassing locks, or unpatched vulnerabilities
  ("ZeroDay", "RogueAI", "DarkNexus" and similar) tend to get extra scrutiny in Play Store
  review and can get rejected under the deceptive-behaviour policy. "CipherX" was chosen
  for that reason - it reads as encryption, not intrusion. Changing the name is a one-line
  edit in `strings.xml`.

## Costs

Gemini's free tier covers generous daily usage for testing. Beyond that it is paid per
token - roughly a few paise per short conversation on `gemini-2.5-flash`. Set a budget
alert in Google Cloud before you publish.

---

## Getting an APK without installing Android Studio

If you only want the installable file and do not want to set up a laptop build
environment, use the free GitHub route. The project already includes
`.github/workflows/build-apk.yml`, so GitHub compiles it for you.

1. Create a free GitHub account and a new **private** repository named `CipherX`.
2. Upload this whole folder to it (on github.com: **Add file > Upload files**,
   drag the contents in, commit).
3. Open the **Actions** tab. The "Build APK" job starts on its own and takes
   about 3-4 minutes.
4. When it turns green, open the finished run and download the artifact
   **CipherX-debug-apk**. Unzip it - inside is `app-debug.apk`.
5. Send that APK to your phone (WhatsApp, Drive, USB) and install it.
   Android will ask you to allow installs from that source - allow it once.

This is the same APK you would get from Android Studio, and it is signed with a
debug key, which is fine for testing and for sharing with friends. For Play Store
you need a release build signed with your own keystore (see above).

## If you want me to keep going

Tell me which direction and the next version can add it:

- Voice input and spoken replies
- Photo understanding (send a picture, ask about it)
- Streaming replies that appear word by word
- Chat history saved on the device
- Your own branding: name, colours, launcher icon


## Version 2.1 dashboard update

The Android dashboard now uses a tactical HUD layout based on the user's supplied video reference: monochrome dark command panels, amber/white instrumentation, animated radar sweep, globe/network visualization, telemetry waveforms, and compact status metrics. Metrics that are not connected to live sensors are illustrative UI indicators and must not be treated as real device telemetry.
