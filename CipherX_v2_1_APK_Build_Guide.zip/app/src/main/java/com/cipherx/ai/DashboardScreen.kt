package com.cipherx.ai

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

private val HudWhite = Color(0xFFD7E0DF)
private val HudMuted = Color(0xFF718080)
private val HudGold = Color(0xFFC99B42)
private val HudPanel = Color(0xFF080D0E)
private val HudLine = Color(0xFF344144)

@Composable
fun DashboardScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    val lang = state.language
    val cfg = remember(state.providerId, state.settingsRev) {
        vm.settingsStore().config(state.providerId)
    }
    val pulse = rememberInfiniteTransition(label = "hud-pulse")
    val sweep by pulse.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing)),
        label = "radar-sweep"
    )
    val scan by pulse.animateFloat(
        initialValue = 0.35f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(1800), repeatMode = RepeatMode.Reverse),
        label = "scan-pulse"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030607))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("CIPHERX  /  COMMAND", color = HudWhite, fontSize = 17.sp)
                Text(
                    tr(lang, "TACTICAL INTELLIGENCE SYSTEM", "टॅक्टिकल इंटेलिजन्स सिस्टम"),
                    color = HudMuted, fontSize = 9.sp, letterSpacing = 2.sp
                )
            }
            Text("● SYSTEM ONLINE", color = Color(0xFF9DB7AC), fontSize = 9.sp)
        }
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            HudMetric("COVERAGE AREA", "80.0", "KM²", Modifier.weight(1f))
            HudMetric("SPEED / FLOW", "38", "KM/H", Modifier.weight(1f))
            HudMetric("AI NODES", "${state.conversations.size.coerceAtLeast(1)}", "ACTIVE", Modifier.weight(1f))
        }
        Spacer(Modifier.height(9.dp))

        // Main tactical map / holographic globe panel inspired by the supplied video.
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, HudLine, RoundedCornerShape(5.dp))
                .background(HudPanel, RoundedCornerShape(5.dp))
                .padding(8.dp)
        ) {
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("GLOBAL / NETWORK MAP", color = HudMuted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                    Text("LIVE FEED  •  60 FPS", color = HudGold, fontSize = 9.sp)
                }
                Spacer(Modifier.height(5.dp))
                Box(Modifier.fillMaxWidth().aspectRatio(1.08f)) {
                    HudGlobe(
                        modifier = Modifier.fillMaxSize(),
                        rotation = sweep,
                        pulse = scan
                    )
                    Column(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("C X", color = HudWhite.copy(alpha = 0.88f), fontSize = 27.sp, letterSpacing = 5.sp)
                        Text("CIPHER CORE", color = HudGold, fontSize = 8.sp, letterSpacing = 2.sp)
                    }
                    Column(Modifier.align(Alignment.BottomStart)) {
                        Text("LAT  19.9975° N", color = HudMuted, fontSize = 8.sp)
                        Text("LON  73.7898° E", color = HudMuted, fontSize = 8.sp)
                    }
                    Column(Modifier.align(Alignment.BottomEnd), horizontalAlignment = Alignment.End) {
                        Text("SECTOR 07", color = HudGold, fontSize = 8.sp)
                        Text("ENCRYPTED LINK", color = HudMuted, fontSize = 8.sp)
                    }
                }
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    HudTag("RADAR SCAN", HudGold)
                    HudTag("ENCRYPTION ACTIVE", Color(0xFF9DB7AC))
                    HudTag("NODE ${cfg.provider.name.uppercase()}", HudWhite)
                }
            }
        }

        Spacer(Modifier.height(9.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudMiniPanel(
                title = "SIGNAL ANALYSIS",
                value = "98.4%",
                caption = "LINK STABILITY",
                modifier = Modifier.weight(1f)
            )
            HudMiniPanel(
                title = "CORE LOAD",
                value = "24.8%",
                caption = "PROCESSING",
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudMiniPanel(
                title = "AI OPERATIONS",
                value = "${state.messages.size}",
                caption = "MESSAGES PROCESSED",
                modifier = Modifier.weight(1f)
            )
            HudMiniPanel(
                title = "MODEL LINK",
                value = if (cfg.apiKey.isNotBlank()) "READY" else "SETUP",
                caption = cfg.provider.name.uppercase(),
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(Modifier.height(9.dp))
        HudGraphPanel()
        Spacer(Modifier.height(9.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("CIPHERX // TACTICAL CONSOLE", color = HudMuted, fontSize = 8.sp, letterSpacing = 1.2.sp)
            Text("V2.1  •  PHASE 02", color = HudGold, fontSize = 8.sp)
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun HudMetric(label: String, number: String, unit: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .border(1.dp, HudLine, RoundedCornerShape(3.dp))
            .background(HudPanel)
            .padding(horizontal = 8.dp, vertical = 9.dp)
    ) {
        Text(label, color = HudMuted, fontSize = 7.sp, letterSpacing = 0.7.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(number, color = HudWhite, fontSize = 20.sp)
            Spacer(Modifier.width(3.dp))
            Text(unit, color = HudGold, fontSize = 8.sp, modifier = Modifier.padding(bottom = 3.dp))
        }
    }
}

@Composable
private fun HudTag(text: String, color: Color) {
    Text(
        text = text,
        color = color,
        fontSize = 7.sp,
        letterSpacing = 0.5.sp,
        modifier = Modifier
            .border(1.dp, color.copy(alpha = 0.55f), RoundedCornerShape(2.dp))
            .padding(horizontal = 5.dp, vertical = 4.dp)
    )
}

@Composable
private fun HudMiniPanel(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .border(1.dp, HudLine, RoundedCornerShape(3.dp))
            .background(HudPanel)
            .padding(9.dp)
    ) {
        Text(title, color = HudMuted, fontSize = 8.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = HudWhite, fontSize = 21.sp)
        Text(caption, color = HudGold, fontSize = 7.sp, letterSpacing = 0.8.sp)
        Spacer(Modifier.height(5.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
            val bars = listOf(0.35f, 0.62f, 0.48f, 0.8f, 0.55f, 0.92f, 0.67f, 0.76f, 0.43f, 0.7f)
            bars.forEachIndexed { i, h ->
                Box(
                    Modifier
                        .weight(1f)
                        .height((17 * h).dp)
                        .background(if (i == 5) HudGold else HudLine)
                )
            }
        }
    }
}

@Composable
private fun HudGraphPanel() {
    Column(
        Modifier
            .fillMaxWidth()
            .border(1.dp, HudLine, RoundedCornerShape(3.dp))
            .background(HudPanel)
            .padding(9.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("TELEMETRY / WAVEFORM", color = HudMuted, fontSize = 8.sp, letterSpacing = 1.sp)
            Text("MONITORING", color = HudGold, fontSize = 8.sp)
        }
        Canvas(Modifier.fillMaxWidth().height(65.dp)) {
            val step = size.width / 42f
            for (i in 0..5) {
                val y = size.height * i / 5f
                drawLine(HudLine.copy(alpha = 0.5f), Offset(0f, y), Offset(size.width, y), 1f)
            }
            val path = Path()
            for (i in 0..41) {
                val x = i * step
                val y = size.height * (0.5f + 0.28f * sin(i * 0.72f) + 0.1f * cos(i * 1.7f))
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, HudWhite.copy(alpha = 0.9f), style = Stroke(width = 1.5f))
        }
    }
}

@Composable
private fun HudGlobe(modifier: Modifier, rotation: Float, pulse: Float) {
    Canvas(modifier = modifier) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val radius = minOf(size.width, size.height) * 0.37f
        val center = Offset(cx, cy)
        // Outer tactical rings.
        drawCircle(HudMuted.copy(alpha = 0.48f), radius * 1.28f, center, style = Stroke(1f))
        drawCircle(HudGold.copy(alpha = 0.85f), radius * 1.12f, center, style = Stroke(2.2f))
        drawCircle(HudWhite.copy(alpha = 0.7f), radius, center, style = Stroke(1.1f))
        drawCircle(HudMuted.copy(alpha = 0.35f), radius * 0.72f, center, style = Stroke(1f))
        // Globe longitude and latitude curves.
        for (factor in listOf(0.32f, 0.62f, 0.88f)) {
            drawOval(
                HudMuted.copy(alpha = 0.42f),
                topLeft = Offset(cx - radius * factor, cy - radius),
                size = Size(radius * factor * 2f, radius * 2f),
                style = Stroke(0.8f)
            )
        }
        for (factor in listOf(-0.62f, -0.3f, 0.3f, 0.62f)) {
            val y = cy + radius * factor
            val half = radius * kotlin.math.sqrt(1f - factor * factor)
            drawLine(HudMuted.copy(alpha = 0.35f), Offset(cx - half, y), Offset(cx + half, y), 0.8f)
        }
        // Abstract land / network contours.
        val contours = listOf(
            listOf(-0.68f to -0.18f, -0.38f to -0.42f, -0.08f to -0.3f, 0.06f to -0.04f, -0.18f to 0.14f, -0.44f to 0.02f),
            listOf(0.08f to -0.55f, 0.48f to -0.43f, 0.7f to -0.14f, 0.42f to 0.02f, 0.28f to 0.38f, 0.04f to 0.22f),
            listOf(-0.35f to 0.34f, -0.08f to 0.28f, 0.12f to 0.53f, -0.02f to 0.72f, -0.26f to 0.55f)
        )
        contours.forEach { points ->
            val path = Path()
            points.forEachIndexed { i, p ->
                val x = cx + p.first * radius
                val y = cy + p.second * radius
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, HudWhite.copy(alpha = 0.08f))
            drawPath(path, HudWhite.copy(alpha = 0.75f), style = Stroke(1.15f))
        }
        // Moving radar sweep wedge and scanning arc.
        drawArc(
            color = HudGold.copy(alpha = 0.16f * pulse),
            startAngle = rotation,
            sweepAngle = 42f,
            useCenter = true,
            topLeft = Offset(cx - radius * 1.1f, cy - radius * 1.1f),
            size = Size(radius * 2.2f, radius * 2.2f)
        )
        drawArc(
            color = HudWhite.copy(alpha = 0.8f),
            startAngle = rotation,
            sweepAngle = 55f,
            useCenter = false,
            topLeft = Offset(cx - radius * 1.22f, cy - radius * 1.22f),
            size = Size(radius * 2.44f, radius * 2.44f),
            style = Stroke(1.4f)
        )
        // Network nodes.
        val nodes = listOf(-0.48f to -0.12f, 0.43f to -0.3f, 0.25f to 0.4f, -0.18f to 0.5f)
        nodes.forEachIndexed { i, p ->
            val point = Offset(cx + p.first * radius, cy + p.second * radius)
            drawCircle(HudGold.copy(alpha = 0.18f), 9f + pulse * 3f, point)
            drawCircle(HudWhite, 3.3f, point)
            drawCircle(HudGold, 7f, point, style = Stroke(1f))
            if (i < nodes.lastIndex) {
                val next = nodes[i + 1]
                drawLine(
                    HudGold.copy(alpha = 0.45f),
                    point,
                    Offset(cx + next.first * radius, cy + next.second * radius),
                    1f
                )
            }
        }
        // Small radial ticks.
        for (i in 0 until 48) {
            val a = Math.toRadians((i * 7.5).toDouble())
            val r1 = radius * 1.15f
            val r2 = if (i % 4 == 0) radius * 1.23f else radius * 1.19f
            drawLine(
                HudWhite.copy(alpha = if (i % 4 == 0) 0.65f else 0.25f),
                Offset(cx + cos(a).toFloat() * r1, cy + sin(a).toFloat() * r1),
                Offset(cx + cos(a).toFloat() * r2, cy + sin(a).toFloat() * r2),
                1f
            )
        }
    }
}
