package com.cipherx.ai

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp

private const val TAB_DASHBOARD = 0
private const val TAB_CHAT = 1
private const val TAB_MODELS = 2
private const val TAB_HISTORY = 3
private const val TAB_SETTINGS = 4
private const val TAB_AGENTS = 5

@Composable
fun CipherXApp(vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    val lang = state.language
    var tab by rememberSaveable { mutableStateOf(TAB_CHAT) }

    // Spoken replies live here so they keep working whichever tab is open.
    val context = LocalContext.current
    val speaker = remember { Speaker(context) }
    DisposableEffect(Unit) { onDispose { speaker.shutdown() } }
    LaunchedEffect(state.pendingSpeech) {
        val text = state.pendingSpeech
        if (text != null) {
            val ok = speaker.speak(text, lang)
            vm.speechDone(!ok)
        }
    }
    LaunchedEffect(state.isLoading) {
        if (state.isLoading) speaker.stop()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Panel) {
                val items = listOf(
                    Triple(TAB_DASHBOARD, "◈", tr(lang, "Home", "होम")),
                    Triple(TAB_CHAT, "✦", tr(lang, "Chat", "चॅट")),
                    Triple(TAB_MODELS, "⚙", tr(lang, "Models", "मॉडेल")),
                    Triple(TAB_HISTORY, "☰", tr(lang, "History", "हिस्टरी")),
                    Triple(TAB_SETTINGS, "☼", tr(lang, "Settings", "सेटिंग्ज")),
                    Triple(TAB_AGENTS, "⬡", tr(lang, "Agents", "एजंट"))
                )
                items.forEach { (id, symbol, label) ->
                    NavigationBarItem(
                        selected = tab == id,
                        onClick = { tab = id },
                        icon = { Text(symbol, fontSize = 18.sp) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Neon,
                            selectedTextColor = Neon,
                            unselectedIconColor = TextDim,
                            unselectedTextColor = TextDim,
                            indicatorColor = PanelHigh
                        )
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                TAB_DASHBOARD -> DashboardScreen(vm)
                TAB_CHAT -> ChatScreen(vm, onOpenModels = { tab = TAB_MODELS })
                TAB_MODELS -> ModelsScreen(vm)
                TAB_HISTORY -> HistoryScreen(vm, onOpened = { tab = TAB_CHAT })
                TAB_SETTINGS -> SettingsScreen(vm)
                else -> AgentsScreen(vm, onOpenChat = { tab = TAB_CHAT })
            }
        }
    }
}
