package com.cipherx.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class AiException(message: String) : Exception(message)

/**
 * One entry point for every AI provider. Gemini uses its own REST format;
 * OpenAI, Groq, DeepSeek, Mistral and custom servers share the OpenAI chat format.
 * Replies are streamed: [onDelta] is called with each new piece of text.
 */
class AiGateway {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    suspend fun stream(
        cfg: ActiveConfig,
        history: List<ChatMessage>,
        language: String,
        systemInstruction: String? = null,
        onDelta: (String) -> Unit
    ) {
        if (cfg.apiKey.isBlank()) throw AiException("No API key set for ${cfg.provider.name}.")
        if (cfg.model.isBlank()) throw AiException("No model name set for ${cfg.provider.name}.")
        if (cfg.baseUrl.isBlank()) throw AiException("No base URL set for ${cfg.provider.name}.")

        val usable = history.filter { it.text.isNotBlank() }
        val request = when (cfg.provider.kind) {
            Kind.GEMINI -> geminiRequest(cfg, usable, language, systemInstruction)
            Kind.OPENAI -> openAiRequest(cfg, usable, language, systemInstruction)
        }
        val isGemini = cfg.provider.kind == Kind.GEMINI

        withContext(Dispatchers.IO) {
            val call: Call = client.newCall(request)
            // A blocking read does not notice coroutine cancellation, so cancel the HTTP call too.
            val cancelHandle = currentCoroutineContext()[Job]?.invokeOnCompletion { cause ->
                if (cause != null) call.cancel()
            }
            try {
                call.execute().use { response ->
                    if (!response.isSuccessful) {
                        val raw = response.body?.string().orEmpty()
                        throw AiException(describeError(response.code, raw))
                    }
                    val source = response.body?.source()
                        ?: throw AiException("The server sent an empty response.")
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val line = source.readUtf8Line() ?: break
                        if (!line.startsWith("data:")) continue
                        val data = line.removePrefix("data:").trim()
                        if (data.isEmpty()) continue
                        if (data == "[DONE]") break
                        val piece = try {
                            if (isGemini) parseGemini(data) else parseOpenAi(data)
                        } catch (e: AiException) {
                            throw e
                        } catch (e: Exception) {
                            ""
                        }
                        if (piece.isNotEmpty()) onDelta(piece)
                    }
                }
            } catch (e: IOException) {
                if (call.isCanceled()) throw kotlinx.coroutines.CancellationException("Stopped")
                throw AiException("Network problem: ${e.message ?: "could not reach the server"}")
            } finally {
                cancelHandle?.dispose()
            }
        }
    }

    private fun systemPrompt(language: String, extra: String? = null): String {
        val base = "You are CipherX, a helpful and concise AI assistant running inside an Android app. " +
            "Answer clearly, keep replies short unless the user asks for detail, and reply in the " +
            "same language the user writes in."
        val localized = if (language == "mr") {
            "$base If the user writes in Marathi, answer in Marathi using Devanagari script."
        } else base
        return if (extra.isNullOrBlank()) localized else "$localized\n\n$extra"
    }

    private fun geminiRequest(cfg: ActiveConfig, history: List<ChatMessage>, language: String, extra: String?): Request {
        val contents = JSONArray()
        history.forEach { msg ->
            contents.put(
                JSONObject()
                    .put("role", if (msg.isUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            )
        }
        val gen = JSONObject()
            .put("temperature", 0.7)
            .put("maxOutputTokens", 2048)
        // Only the 2.5 "flash" models allow switching thinking off.
        if (cfg.model.contains("2.5-flash")) {
            gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put(
                    "parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt(language, extra)))
                )
            )
            .put("contents", contents)
            .put("generationConfig", gen)
            .toString()

        return Request.Builder()
            .url("${cfg.baseUrl}${cfg.model}:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", cfg.apiKey)
            .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
    }

    private fun openAiRequest(cfg: ActiveConfig, history: List<ChatMessage>, language: String, extra: String?): Request {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt(language, extra)))
        history.forEach { msg ->
            messages.put(
                JSONObject()
                    .put("role", if (msg.isUser) "user" else "assistant")
                    .put("content", msg.text)
            )
        }
        val body = JSONObject()
            .put("model", cfg.model)
            .put("messages", messages)
            .put("stream", true)
            .put("temperature", 0.7)
            .toString()

        return Request.Builder()
            .url("${cfg.baseUrl.trimEnd('/')}/chat/completions")
            .addHeader("Authorization", "Bearer ${cfg.apiKey}")
            .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
    }

    private fun parseGemini(data: String): String {
        val root = JSONObject(data)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val blocked = root.optJSONObject("promptFeedback")?.optString("blockReason")
            if (!blocked.isNullOrBlank()) {
                throw AiException("The request was blocked ($blocked). Try rephrasing.")
            }
            return ""
        }
        val parts = candidates.getJSONObject(0)
            .optJSONObject("content")
            ?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.getJSONObject(i)
            if (!part.isNull("text")) sb.append(part.optString("text"))
        }
        return sb.toString()
    }

    private fun parseOpenAi(data: String): String {
        val root = JSONObject(data)
        val choices = root.optJSONArray("choices")
        if (choices == null || choices.length() == 0) return ""
        val delta = choices.getJSONObject(0).optJSONObject("delta") ?: return ""
        return if (delta.isNull("content")) "" else delta.optString("content")
    }

    private fun describeError(code: Int, raw: String): String {
        val detail = runCatching {
            val err = JSONObject(raw).opt("error")
            when (err) {
                is JSONObject -> err.optString("message")
                is String -> err
                else -> ""
            }
        }.getOrNull()

        val base = when (code) {
            400 -> "The request was rejected. Check the key and the model name."
            401, 403 -> "This API key is not authorised. Add a valid key in the Models tab."
            404 -> "That model or address was not found. Check the model name."
            429 -> "Rate limit or quota reached. Wait a minute and try again."
            in 500..599 -> "The AI service is busy right now. Try again shortly."
            else -> "Request failed (HTTP $code)."
        }
        return if (detail.isNullOrBlank()) base else "$base\n\n$detail"
    }
}
