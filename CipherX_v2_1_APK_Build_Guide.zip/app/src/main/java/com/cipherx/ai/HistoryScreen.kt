package com.cipherx.ai

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

@Composable
fun HistoryScreen(vm: ChatViewModel, onOpened: () -> Unit) {
    val state by vm.state.collectAsState()
    val lang = state.language
    val fmt = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT)

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        ScreenTitle(
            title = tr(lang, "Chat history", "चॅट हिस्टरी"),
            subtitle = tr(lang, "Saved only on this phone", "फक्त या फोनमध्ये सेव्ह")
        )
        if (state.conversations.isEmpty()) {
            Text(
                tr(lang, "No saved chats yet.", "अजून कोणतेही चॅट सेव्ह नाहीत."),
                color = TextDim
            )
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                items(state.conversations, key = { it.id }) { conv ->
                    NeonCard(
                        modifier = Modifier.clickable {
                            vm.openConversation(conv.id)
                            onOpened()
                        }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(conv.title, color = TextMain, fontSize = 15.sp, maxLines = 2)
                                Text(
                                    fmt.format(Date(conv.updatedAt)) + " · " +
                                        conv.messages.size + tr(lang, " messages", " संदेश"),
                                    color = TextDim,
                                    fontSize = 11.sp
                                )
                            }
                            TextButton(onClick = { vm.deleteConversation(conv.id) }) {
                                Text(tr(lang, "Delete", "हटवा"), color = NeonRed)
                            }
                        }
                    }
                }
            }
        }
    }
}
