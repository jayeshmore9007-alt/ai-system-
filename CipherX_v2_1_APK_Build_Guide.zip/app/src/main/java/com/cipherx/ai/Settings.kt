package com.cipherx.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

enum class Kind { GEMINI, OPENAI }

data class Provider(
    val id: String,
    val name: String,
    val kind: Kind,
    val baseUrl: String,
    val defaultModel: String,
    val suggestions: List<String>,
    val keyUrl: String
)

object Providers {
    val all: List<Provider> = listOf(
        Provider(
            id = "gemini",
            name = "Google Gemini",
            kind = Kind.GEMINI,
            baseUrl = "https://generativelanguage.googleapis.com/v1beta/models/",
            defaultModel = "gemini-2.5-flash",
            suggestions = listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"),
            keyUrl = "aistudio.google.com/apikey"
        ),
        Provider(
            id = "openai",
            name = "OpenAI",
            kind = Kind.OPENAI,
            baseUrl = "https://api.openai.com/v1",
            defaultModel = "gpt-4o-mini",
            suggestions = listOf("gpt-4o-mini", "gpt-4o"),
            keyUrl = "platform.openai.com/api-keys"
        ),
        Provider(
            id = "groq",
            name = "Groq",
            kind = Kind.OPENAI,
            baseUrl = "https://api.groq.com/openai/v1",
            defaultModel = "llama-3.3-70b-versatile",
            suggestions = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant"),
            keyUrl = "console.groq.com/keys"
        ),
        Provider(
            id = "deepseek",
            name = "DeepSeek",
            kind = Kind.OPENAI,
            baseUrl = "https://api.deepseek.com/v1",
            defaultModel = "deepseek-chat",
            suggestions = listOf("deepseek-chat", "deepseek-reasoner"),
            keyUrl = "platform.deepseek.com/api_keys"
        ),
        Provider(
            id = "mistral",
            name = "Mistral",
            kind = Kind.OPENAI,
            baseUrl = "https://api.mistral.ai/v1",
            defaultModel = "mistral-small-latest",
            suggestions = listOf("mistral-small-latest", "mistral-large-latest"),
            keyUrl = "console.mistral.ai/api-keys"
        ),
        Provider(
            id = "custom",
            name = "Custom (OpenAI-compatible)",
            kind = Kind.OPENAI,
            baseUrl = "",
            defaultModel = "",
            suggestions = emptyList(),
            keyUrl = ""
        )
    )

    fun byId(id: String): Provider = all.firstOrNull { it.id == id } ?: all.first()
}

data class ActiveConfig(
    val provider: Provider,
    val baseUrl: String,
    val model: String,
    val apiKey: String
)

/**
 * Stores settings. API keys go into EncryptedSharedPreferences (Android Keystore).
 * If the device cannot provide encrypted storage, [isEncrypted] is false and the UI says so.
 */
class SettingsStore(context: Context) {

    private val ctx = context.applicationContext
    private val plain: SharedPreferences =
        ctx.getSharedPreferences("cipherx_settings", Context.MODE_PRIVATE)

    val isEncrypted: Boolean
    private val secure: SharedPreferences

    init {
        var encrypted = true
        secure = try {
            val masterKey = MasterKey.Builder(ctx)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                ctx,
                "cipherx_secure",
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            encrypted = false
            ctx.getSharedPreferences("cipherx_secure_fallback", Context.MODE_PRIVATE)
        }
        isEncrypted = encrypted
        migrateOldKey()
    }

    /** Version 1 of the app saved the Gemini key in plain storage; move it. */
    private fun migrateOldKey() {
        val old = ctx.getSharedPreferences("cipherx_prefs", Context.MODE_PRIVATE)
        val oldKey = old.getString("gemini_api_key", "").orEmpty()
        if (oldKey.isNotBlank()) {
            if (key("gemini").isBlank()) setKey("gemini", oldKey)
            old.edit().remove("gemini_api_key").apply()
        }
    }

    var providerId: String
        get() = plain.getString("provider", "gemini").orEmpty()
        set(v) = plain.edit().putString("provider", v).apply()

    var language: String
        get() = plain.getString("language", "en").orEmpty()
        set(v) = plain.edit().putString("language", v).apply()

    var speak: Boolean
        get() = plain.getBoolean("speak", false)
        set(v) = plain.edit().putBoolean("speak", v).apply()

    fun key(pid: String): String = secure.getString("key_$pid", "").orEmpty()

    fun setKey(pid: String, value: String) {
        secure.edit().putString("key_$pid", value.trim()).apply()
    }

    fun model(pid: String): String {
        val saved = plain.getString("model_$pid", "").orEmpty()
        return if (saved.isNotBlank()) saved else Providers.byId(pid).defaultModel
    }

    fun setModel(pid: String, value: String) {
        plain.edit().putString("model_$pid", value.trim()).apply()
    }

    fun baseUrl(pid: String): String {
        val p = Providers.byId(pid)
        if (p.id != "custom") return p.baseUrl
        return plain.getString("base_$pid", "").orEmpty().trim().trimEnd('/')
    }

    fun setBaseUrl(pid: String, value: String) {
        plain.edit().putString("base_$pid", value.trim().trimEnd('/')).apply()
    }

    fun config(pid: String = providerId): ActiveConfig {
        val p = Providers.byId(pid)
        return ActiveConfig(p, baseUrl(p.id), model(p.id), key(p.id))
    }

    fun clearAll() {
        plain.edit().clear().apply()
        secure.edit().clear().apply()
    }
}
