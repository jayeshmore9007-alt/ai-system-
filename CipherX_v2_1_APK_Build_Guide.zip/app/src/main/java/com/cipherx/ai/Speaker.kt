package com.cipherx.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/** Reads replies aloud with the phone's built-in text-to-speech engine. */
class Speaker(context: Context) {

    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    /** Returns false when the engine or the language voice is not available. */
    fun speak(text: String, language: String): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        val locale = if (language == "mr") Locale("mr", "IN") else Locale.US
        val result = engine.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            return false
        }
        engine.speak(text.take(3500), TextToSpeech.QUEUE_FLUSH, null, "cipherx-reply")
        return true
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
