package com.cipherx.ai

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Neon = Color(0xFF00FF9C)
val NeonDim = Color(0xFF0B5A3C)
val NeonAmber = Color(0xFFFFC107)
val NeonRed = Color(0xFFFF5252)
val Ink = Color(0xFF000000)
val Panel = Color(0xFF07100B)
val PanelHigh = Color(0xFF0E1A13)
val TextMain = Color(0xFFE6FFF3)
val TextDim = Color(0xFF8FB5A2)

/** Returns the Marathi text when the app language is "mr", otherwise English. */
fun tr(lang: String, en: String, mr: String): String = if (lang == "mr") mr else en

@Composable
fun CipherXTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon,
            onPrimary = Ink,
            secondary = Neon,
            onSecondary = Ink,
            background = Ink,
            onBackground = TextMain,
            surface = Panel,
            onSurface = TextMain,
            surfaceVariant = PanelHigh,
            onSurfaceVariant = TextMain,
            outline = NeonDim,
            error = NeonRed
        ),
        content = content
    )
}

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, NeonDim),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
fun StatusBadge(text: String, color: Color) {
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(50),
        border = BorderStroke(1.dp, color)
    ) {
        Text(
            text = text,
            color = color,
            fontSize = 11.sp,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Text(
            text = title,
            color = Neon,
            fontSize = 22.sp,
            style = MaterialTheme.typography.titleLarge
        )
        if (subtitle != null) {
            Text(text = subtitle, color = TextDim, fontSize = 12.sp)
        }
    }
}
