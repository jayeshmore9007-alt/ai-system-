package com.cipherx.ai

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val agentIcons = mapOf(
    "cipher-core" to "✦", "wifi-sentinel" to "⌁", "device-scanner" to "◎",
    "flipper-agent" to "◈", "esp32-agent" to "⌘", "pager-x-agent" to "⌬",
    "instagram-agent" to "▣", "code-master" to "⌨", "apk-builder" to "⬡",
    "repair-agent" to "⚒", "research-agent" to "⌕", "voice-agent" to "♫",
    "automation-agent" to "⟳", "security-guard" to "⬢", "documentation-agent" to "▤"
)

private val agentColors = listOf(
    Color(0xFF00F5A0), Color(0xFF32D7FF), Color(0xFF9C7BFF), Color(0xFFFFB547), Color(0xFFFF6F91)
)

@Composable
fun AgentsScreen(vm: ChatViewModel, onOpenChat: () -> Unit) {
    var selected by remember { mutableStateOf<AgentDefinition?>(null) }
    AnimatedContent(
        targetState = selected,
        transitionSpec = { (fadeIn(tween(220)) + scaleIn(initialScale = 0.985f)) togetherWith fadeOut(tween(140)) },
        label = "agent-pages"
    ) { agent ->
        if (agent == null) AgentDirectory(vm) { selected = it }
        else AgentWorkspace(vm, agent, onBack = { selected = null })
    }
}

@Composable
private fun AgentDirectory(vm: ChatViewModel, onSelect: (AgentDefinition) -> Unit) {
    val state by vm.state.collectAsState()
    val lang = state.language
    val cfg = remember(state.providerId, state.settingsRev) { vm.settingsStore().config(state.providerId) }
    val liveCount = cipherAgents.count { it.state == AgentState.LIVE }
    val pulse = rememberInfiniteTransition(label = "core-pulse")
    val glow by pulse.animateFloat(0.35f, 0.9f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF06140F), Ink, Color(0xFF020706)))),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("CIPHERX // AGENT NETWORK", color = TextDim, fontSize = 10.sp, letterSpacing = 2.sp)
                    Text(tr(lang, "Your AI command crew", "तुमची AI एजंट टीम"), color = TextMain, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text(tr(lang, "Choose a specialist. Start a private conversation.", "तज्ज्ञ निवडा आणि स्वतंत्र संभाषण सुरू करा."), color = TextDim, fontSize = 12.sp)
                }
                Box(Modifier.size(48.dp).clip(CircleShape).background(Neon.copy(alpha = glow * .16f)), contentAlignment = Alignment.Center) {
                    Text("✦", color = Neon, fontSize = 28.sp)
                }
            }
        }
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0A2118)),
                border = BorderStroke(1.dp, Neon.copy(alpha = .55f)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("CIPHER CORE", color = Neon, fontSize = 19.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(tr(lang, "Central intelligence", "मुख्य AI सहाय्यक"), color = TextDim, fontSize = 12.sp)
                        }
                        Surface(color = Neon.copy(alpha = .14f), shape = CircleShape, border = BorderStroke(1.dp, Neon.copy(alpha = .6f))) {
                            Text("ONLINE", color = Neon, modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text(tr(lang, "15 specialist personalities · one selected AI provider · separate conversations", "१५ तज्ज्ञ भूमिका · निवडलेला AI provider · स्वतंत्र संभाषणे"), color = TextMain, fontSize = 13.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MetricPill("${cipherAgents.size}", tr(lang, "AGENTS", "एजंट"))
                        MetricPill("$liveCount", tr(lang, "LOCAL TOOLS", "स्थानिक साधने"))
                        MetricPill(cfg.provider.name, "AI ENGINE")
                    }
                    Button(onClick = { onSelect(cipherAgents.first()) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Ink), shape = RoundedCornerShape(14.dp)) {
                        Text(tr(lang, "Talk to CIPHER CORE  →", "CIPHER CORE शी बोला  →"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(tr(lang, "SPECIALIST AGENTS", "तज्ज्ञ AI एजंट"), color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp)
                Spacer(Modifier.weight(1f))
                Text(tr(lang, "Tap to open dashboard", "डॅशबोर्ड उघडण्यासाठी टॅप करा"), color = TextDim, fontSize = 10.sp)
            }
        }
        items(cipherAgents.drop(1), key = { it.id }) { agent ->
            AgentTile(agent = agent, index = cipherAgents.indexOf(agent), lang = lang, onClick = { onSelect(agent) })
        }
        item {
            Text(tr(lang, "All agents can hold role-based AI conversations. Hardware, account and device actions remain unavailable until their real integrations are connected.", "सर्व एजंट त्यांच्या भूमिकेनुसार AI संभाषण करू शकतात. हार्डवेअर, खाते आणि डिव्हाइसवरील कृतींसाठी प्रत्यक्ष integration जोडणे आवश्यक आहे."), color = TextDim, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
private fun MetricPill(value: String, label: String) {
    Surface(color = Color(0xFF10291F), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(horizontal = 11.dp, vertical = 7.dp)) {
            Text(value, color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(label, color = TextDim, fontSize = 8.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
private fun AgentTile(agent: AgentDefinition, index: Int, lang: String, onClick: () -> Unit) {
    val accent = agentColors[index % agentColors.size]
    var pressed by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth().animateContentSize().clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Color(0xFF091710)),
        border = BorderStroke(1.dp, accent.copy(alpha = .32f)),
        shape = RoundedCornerShape(19.dp)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(15.dp)).background(accent.copy(alpha = .13f)), contentAlignment = Alignment.Center) {
                Text(agentIcons[agent.id] ?: "✦", color = accent, fontSize = 24.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(agent.name, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = .5.sp)
                Text(tr(lang, agent.role, agent.role), color = TextDim, fontSize = 11.sp)
                Text(tr(lang, "Dedicated AI workspace", "स्वतंत्र AI कार्यक्षेत्र"), color = accent, fontSize = 9.sp)
            }
            Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Surface(color = accent.copy(alpha = .12f), shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, accent.copy(alpha = .5f))) {
                    Text("CHAT", color = accent, modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
                Text("↗", color = accent, fontSize = 19.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AgentWorkspace(vm: ChatViewModel, agent: AgentDefinition, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val lang = state.language
    val accent = agentColors[cipherAgents.indexOf(agent).coerceAtLeast(0) % agentColors.size]
    val messages = remember(agent.id) { mutableStateListOf<ChatMessage>().apply { addAll(vm.loadAgentHistory(agent.id)) } }
    var input by remember(agent.id) { mutableStateOf("") }
    var loading by remember(agent.id) { mutableStateOf(false) }
    var error by remember(agent.id) { mutableStateOf<String?>(null) }
    val pulse = rememberInfiniteTransition(label = "agent-live")
    val glow by pulse.animateFloat(.25f, .85f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "agent-glow")

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF071810), Ink, Color(0xFF030907))))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("←  ${tr(lang, "AGENTS", "एजंट्स")}", color = Neon) }
            Spacer(Modifier.weight(1f))
            Text("PRIVATE WORKSPACE", color = TextDim, fontSize = 9.sp, letterSpacing = 1.3.sp)
        }
        Card(Modifier.fillMaxWidth().padding(horizontal = 14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF0A2118)), border = BorderStroke(1.dp, accent.copy(alpha = .5f)), shape = RoundedCornerShape(22.dp)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(58.dp).clip(RoundedCornerShape(18.dp)).background(accent.copy(alpha = .14f)), contentAlignment = Alignment.Center) {
                    Text(agentIcons[agent.id] ?: "✦", color = accent, fontSize = 30.sp)
                }
                Spacer(Modifier.width(13.dp))
                Column(Modifier.weight(1f)) {
                    Text(agent.name, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(agent.role, color = TextMain, fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(6.dp).clip(CircleShape).background(if (loading) NeonAmber else Neon.copy(alpha = glow)))
                        Spacer(Modifier.width(5.dp))
                        Text(if (loading) tr(lang, "THINKING…", "विचार करत आहे…") else tr(lang, "READY · ${vm.settingsStore().config().provider.name}", "तयार · ${vm.settingsStore().config().provider.name}"), color = TextDim, fontSize = 9.sp)
                    }
                }
            }
        }
        Text(agent.detail, color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp))
        if (messages.isEmpty()) {
            Column(Modifier.weight(1f).fillMaxWidth().padding(26.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(86.dp).clip(CircleShape).background(accent.copy(alpha = .08f)), contentAlignment = Alignment.Center) {
                    Text(agentIcons[agent.id] ?: "✦", color = accent.copy(alpha = glow), fontSize = 42.sp)
                }
                Spacer(Modifier.height(18.dp))
                Text(tr(lang, "Your ${agent.name} workspace", "तुमचे ${agent.name} कार्यक्षेत्र"), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Text(tr(lang, "Start talking naturally. This agent will answer in its specialist role.", "नैसर्गिकपणे बोला. हा एजंट त्याच्या तज्ज्ञ भूमिकेत उत्तर देईल."), color = TextDim, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                Surface(color = Color(0xFF0B1D14), shape = RoundedCornerShape(14.dp), border = BorderStroke(1.dp, accent.copy(alpha = .3f))) {
                    Text(tr(lang, "Separate chat · Dedicated personality · Streaming replies", "स्वतंत्र चॅट · स्वतंत्र भूमिका · थेट येणारी उत्तरे"), color = accent, fontSize = 10.sp, modifier = Modifier.padding(12.dp))
                }
            }
        } else {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(messages.size) { i ->
                    val msg = messages[i]
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start) {
                        Surface(color = if (msg.isUser) accent else Color(0xFF0D1C14), shape = RoundedCornerShape(17.dp), border = if (msg.isUser) null else BorderStroke(1.dp, accent.copy(alpha = .22f)), modifier = Modifier.fillMaxWidth(.88f)) {
                            Text(msg.text.ifBlank { if (loading && i == messages.lastIndex) "…" else "" }, color = if (msg.isUser) Ink else TextMain, fontSize = 14.sp, modifier = Modifier.padding(13.dp))
                        }
                    }
                }
            }
        }
        error?.let { Text(it, color = NeonAmber, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp)) }
        Surface(color = Color(0xFF07130D), tonalElevation = 4.dp) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f),
                    placeholder = { Text(tr(lang, "Message ${agent.name}…", "${agent.name} ला संदेश द्या…"), color = TextDim, fontSize = 12.sp) },
                    maxLines = 4, shape = RoundedCornerShape(20.dp), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (!loading && input.isNotBlank()) sendAgentMessage(agent, messages, input, { input = "" }, { loading = it }, { error = it }, vm) }),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, unfocusedBorderColor = accent.copy(alpha = .35f), focusedTextColor = TextMain, unfocusedTextColor = TextMain, cursorColor = accent)
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = { sendAgentMessage(agent, messages, input, { input = "" }, { loading = it }, { error = it }, vm) }, enabled = input.isNotBlank() && !loading, colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink), shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(horizontal = 15.dp, vertical = 14.dp)) {
                    Text(if (loading) "…" else "➤", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun sendAgentMessage(
    agent: AgentDefinition,
    messages: androidx.compose.runtime.snapshots.SnapshotStateList<ChatMessage>,
    text: String,
    clearInput: () -> Unit,
    setLoading: (Boolean) -> Unit,
    setError: (String?) -> Unit,
    vm: ChatViewModel
) {
    val clean = text.trim()
    if (clean.isBlank() || messages.lastOrNull()?.text == "") return
    messages.add(ChatMessage(clean, true))
    messages.add(ChatMessage("", false))
    vm.saveAgentHistory(agent.id, messages.toList())
    clearInput(); setLoading(true); setError(null)
    val history = messages.toList().dropLast(1)
    vm.askAgent(agent, history, onDelta = { delta ->
        val last = messages.lastOrNull()
        if (last != null && !last.isUser) {
            messages[messages.lastIndex] = last.copy(text = last.text + delta)
            vm.saveAgentHistory(agent.id, messages.toList())
        }
    }, onComplete = { problem ->
        setLoading(false)
        if (problem != null) {
            setError(problem)
            if (messages.lastOrNull()?.text.isNullOrBlank()) messages.removeAt(messages.lastIndex)
            vm.saveAgentHistory(agent.id, messages.toList())
        }
    })
}

