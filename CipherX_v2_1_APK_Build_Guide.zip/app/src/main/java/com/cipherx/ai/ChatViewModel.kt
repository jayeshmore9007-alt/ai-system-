package com.cipherx.ai

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withTimeout
import java.util.UUID

data class ChatUiState(
    val conversations: List<Conversation> = emptyList(),
    val currentId: String = "",
    val messages: List<ChatMessage> = emptyList(),
    val isLoading: Boolean = false,
    val error: String? = null,
    val notice: String? = null,
    val pendingSpeech: String? = null,
    val providerId: String = "gemini",
    val language: String = "en",
    val speak: Boolean = false,
    val settingsRev: Int = 0,
    val testResults: Map<String, String> = emptyMap()
)

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val settings = SettingsStore(app)
    private val store = ChatStore(app)
    private val agentStore = AgentChatStore(app)
    private val gateway = AiGateway()
    private var job: Job? = null

    private val _state = MutableStateFlow(
        ChatUiState(
            conversations = store.load().sortedByDescending { it.updatedAt },
            currentId = newId(),
            providerId = settings.providerId,
            language = settings.language,
            speak = settings.speak
        )
    )
    val state: StateFlow<ChatUiState> = _state.asStateFlow()

    /** Read-only access for screens that show key/model fields. */
    fun settingsStore(): SettingsStore = settings

    fun loadAgentHistory(agentId: String): List<ChatMessage> = agentStore.load(agentId)
    fun saveAgentHistory(agentId: String, messages: List<ChatMessage>) = agentStore.save(agentId, messages)

    private fun newId(): String = UUID.randomUUID().toString()

    // ---------- Chat ----------

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        val s = _state.value
        if (trimmed.isEmpty() || s.isLoading) return

        val cfg = settings.config()
        if (cfg.apiKey.isBlank()) {
            _state.update {
                it.copy(
                    error = tr(
                        it.language,
                        "Add an API key for ${cfg.provider.name} in the Models tab first.",
                        "आधी Models टॅबमध्ये ${cfg.provider.name} ची API key टाका."
                    )
                )
            }
            return
        }

        val withUser = s.messages + ChatMessage(trimmed, isUser = true)
        _state.update {
            it.copy(
                messages = withUser + ChatMessage("", isUser = false),
                isLoading = true,
                error = null,
                notice = null,
                pendingSpeech = null
            )
        }

        val language = s.language
        job = viewModelScope.launch {
            val acc = StringBuilder()
            try {
                gateway.stream(cfg, withUser, language) { delta ->
                    acc.append(delta)
                    val partial = acc.toString()
                    _state.update { st ->
                        val list = st.messages.toMutableList()
                        if (list.isNotEmpty() && !list.last().isUser) {
                            list[list.lastIndex] = list.last().copy(text = partial)
                        }
                        st.copy(messages = list)
                    }
                }
                if (acc.isBlank()) {
                    throw AiException(
                        tr(
                            language,
                            "The model returned an empty answer. Try rephrasing.",
                            "मॉडेलने रिकामे उत्तर दिले. प्रश्न वेगळ्या शब्दांत विचारा."
                        )
                    )
                }
                _state.update {
                    it.copy(
                        isLoading = false,
                        pendingSpeech = if (it.speak) acc.toString() else null
                    )
                }
            } catch (e: CancellationException) {
                _state.update { it.copy(isLoading = false) }
                throw e
            } catch (e: Exception) {
                _state.update {
                    it.copy(isLoading = false, error = e.message ?: "Something went wrong.")
                }
            } finally {
                dropEmptyPlaceholder()
                persist()
            }
        }
    }

    fun stop() {
        job?.cancel()
    }

    /** Runs an isolated role-based agent conversation through the selected AI provider. */
    fun askAgent(
        agent: AgentDefinition,
        history: List<ChatMessage>,
        onDelta: (String) -> Unit,
        onComplete: (String?) -> Unit
    ) {
        val cfg = settings.config()
        if (cfg.apiKey.isBlank()) {
            onComplete("Add an API key in Models before chatting with agents.")
            return
        }
        val instruction = """
            You are ${agent.name}, a dedicated CipherX AI specialist.
            Your role: ${agent.role}.
            Mission: ${agent.detail}
            Speak directly with the user as this specialist, not as a generic assistant. Be capable,
            practical, and honest. Ask a focused follow-up when essential details are missing.
            Never claim to have accessed hardware, accounts, networks, files, or external systems
            unless a connected tool actually supplied that result. Explain limitations clearly.
            Reply in the user's language; when they write Marathi, use natural Marathi in Devanagari.
        """.trimIndent()
        viewModelScope.launch {
            try {
                gateway.stream(cfg, history, _state.value.language, instruction) { delta ->
                    viewModelScope.launch(Dispatchers.Main) { onDelta(delta) }
                }
                onComplete(null)
            } catch (e: CancellationException) {
                onComplete("Stopped.")
            } catch (e: Exception) {
                onComplete(e.message ?: "Agent request failed.")
            }
        }
    }

    private fun dropEmptyPlaceholder() {
        _state.update { st ->
            val last = st.messages.lastOrNull()
            if (last != null && !last.isUser && last.text.isBlank()) {
                st.copy(messages = st.messages.dropLast(1))
            } else st
        }
    }

    private fun persist() {
        val s = _state.value
        val msgs = s.messages.filter { it.text.isNotBlank() }
        if (msgs.isEmpty()) return
        val title = msgs.firstOrNull { it.isUser }?.text?.take(40) ?: "Chat"
        val conv = Conversation(s.currentId, title, System.currentTimeMillis(), msgs)
        val list = (s.conversations.filter { it.id != conv.id } + conv)
            .sortedByDescending { it.updatedAt }
        store.save(list)
        _state.update { it.copy(conversations = list) }
    }

    fun newChat() {
        job?.cancel()
        _state.update {
            it.copy(
                currentId = newId(),
                messages = emptyList(),
                isLoading = false,
                error = null,
                notice = null,
                pendingSpeech = null
            )
        }
    }

    fun openConversation(id: String) {
        val conv = _state.value.conversations.firstOrNull { it.id == id } ?: return
        job?.cancel()
        _state.update {
            it.copy(
                currentId = conv.id,
                messages = conv.messages,
                isLoading = false,
                error = null,
                notice = null,
                pendingSpeech = null
            )
        }
    }

    fun deleteConversation(id: String) {
        val list = _state.value.conversations.filter { it.id != id }
        store.save(list)
        _state.update { it.copy(conversations = list) }
        if (_state.value.currentId == id) newChat()
    }

    fun clearError() {
        _state.update { it.copy(error = null) }
    }

    fun speechDone(failed: Boolean) {
        _state.update {
            it.copy(
                pendingSpeech = null,
                notice = if (failed) {
                    tr(
                        it.language,
                        "Spoken replies are not available for this language on your phone.",
                        "या भाषेसाठी फोनमध्ये बोलून उत्तर देण्याची सोय उपलब्ध नाही."
                    )
                } else it.notice
            )
        }
    }

    // ---------- Settings ----------

    fun setProvider(id: String) {
        settings.providerId = id
        _state.update { it.copy(providerId = id) }
    }

    fun setLanguage(lang: String) {
        settings.language = lang
        _state.update { it.copy(language = lang) }
    }

    fun setSpeak(on: Boolean) {
        settings.speak = on
        _state.update { it.copy(speak = on) }
    }

    fun saveProvider(pid: String, key: String, model: String, baseUrl: String) {
        settings.setKey(pid, key)
        settings.setModel(pid, model)
        if (pid == "custom") settings.setBaseUrl(pid, baseUrl)
        _state.update { it.copy(settingsRev = it.settingsRev + 1) }
    }

    fun testProvider(pid: String) {
        val cfg = settings.config(pid)
        val lang = _state.value.language
        if (cfg.apiKey.isBlank()) {
            setTest(pid, tr(lang, "No API key saved.", "API key सेव्ह केलेली नाही."))
            return
        }
        setTest(pid, tr(lang, "Testing…", "तपासत आहे…"))
        viewModelScope.launch {
            val result = try {
                withTimeout(30_000) {
                    val sb = StringBuilder()
                    gateway.stream(
                        cfg,
                        listOf(ChatMessage("Reply with the single word OK.", isUser = true)),
                        "en"
                    ) { sb.append(it) }
                    if (sb.isNotBlank()) "OK" else tr(lang, "Empty reply.", "रिकामे उत्तर.")
                }
            } catch (e: Exception) {
                tr(lang, "Failed: ", "अयशस्वी: ") + (e.message ?: "error").take(200)
            }
            setTest(pid, result)
        }
    }

    private fun setTest(pid: String, text: String) {
        _state.update { it.copy(testResults = it.testResults + (pid to text)) }
    }

    fun clearAllData() {
        job?.cancel()
        settings.clearAll()
        store.save(emptyList())
        _state.value = ChatUiState(
            currentId = newId(),
            providerId = settings.providerId,
            language = settings.language,
            speak = settings.speak,
            settingsRev = _state.value.settingsRev + 1
        )
    }
}
