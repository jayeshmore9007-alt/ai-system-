package com.cipherx.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Conversation(
    val id: String,
    val title: String,
    val updatedAt: Long,
    val messages: List<ChatMessage>
)

/** Saves all chats as one JSON file in the app's private storage. */
class ChatStore(context: Context) {

    private val file = File(context.applicationContext.filesDir, "conversations.json")

    @Synchronized
    fun load(): List<Conversation> {
        return try {
            if (!file.exists()) return emptyList()
            val arr = JSONArray(file.readText())
            val out = ArrayList<Conversation>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ms = o.getJSONArray("messages")
                val messages = ArrayList<ChatMessage>()
                for (j in 0 until ms.length()) {
                    val m = ms.getJSONObject(j)
                    messages.add(ChatMessage(m.getString("text"), m.getBoolean("isUser")))
                }
                out.add(
                    Conversation(
                        id = o.getString("id"),
                        title = o.optString("title"),
                        updatedAt = o.optLong("updatedAt"),
                        messages = messages
                    )
                )
            }
            out
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(list: List<Conversation>) {
        try {
            val arr = JSONArray()
            list.forEach { c ->
                val ms = JSONArray()
                c.messages.forEach { m ->
                    ms.put(JSONObject().put("text", m.text).put("isUser", m.isUser))
                }
                arr.put(
                    JSONObject()
                        .put("id", c.id)
                        .put("title", c.title)
                        .put("updatedAt", c.updatedAt)
                        .put("messages", ms)
                )
            }
            val tmp = File(file.parentFile, "conversations.json.tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.writeText(arr.toString())
                tmp.delete()
            }
        } catch (e: Exception) {
            // Saving history is best-effort; the chat itself keeps working.
        }
    }
}


/** Stores one independent conversation per specialist agent in app-private storage. */
class AgentChatStore(context: Context) {
    private val file = File(context.applicationContext.filesDir, "agent_conversations.json")

    @Synchronized
    fun load(agentId: String): List<ChatMessage> = try {
        if (!file.exists()) return emptyList()
        val root = JSONObject(file.readText())
        val arr = root.optJSONArray(agentId) ?: return emptyList()
        buildList {
            for (i in 0 until arr.length()) {
                val item = arr.getJSONObject(i)
                add(ChatMessage(item.optString("text"), item.optBoolean("isUser")))
            }
        }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    fun save(agentId: String, messages: List<ChatMessage>) {
        try {
            val root = if (file.exists()) JSONObject(file.readText()) else JSONObject()
            val arr = JSONArray()
            messages.filter { it.text.isNotBlank() }.forEach { message ->
                arr.put(JSONObject().put("text", message.text).put("isUser", message.isUser))
            }
            root.put(agentId, arr)
            val tmp = File(file.parentFile, "agent_conversations.json.tmp")
            tmp.writeText(root.toString())
            if (!tmp.renameTo(file)) { file.writeText(root.toString()); tmp.delete() }
        } catch (_: Exception) { /* best-effort private local history */ }
    }
}
