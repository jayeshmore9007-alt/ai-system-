package com.cipherx.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ModelsScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    val lang = state.language

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle(
            title = tr(lang, "AI Model Manager", "AI मॉडेल व्यवस्थापक"),
            subtitle = tr(
                lang,
                "Keys are stored only on this phone.",
                "Keys फक्त या फोनमध्ये साठवल्या जातात."
            )
        )
        Providers.all.forEach { provider ->
            ProviderCard(vm, provider, state)
        }
    }
}

@Composable
private fun ProviderCard(vm: ChatViewModel, provider: Provider, state: ChatUiState) {
    val lang = state.language
    val store = vm.settingsStore()
    val isActive = state.providerId == provider.id

    var key by remember(provider.id, state.settingsRev) { mutableStateOf(store.key(provider.id)) }
    var model by remember(provider.id, state.settingsRev) { mutableStateOf(store.model(provider.id)) }
    var baseUrl by remember(provider.id, state.settingsRev) { mutableStateOf(store.baseUrl(provider.id)) }
    var showKey by remember { mutableStateOf(false) }

    NeonCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(provider.name, color = Neon, fontSize = 16.sp)
                if (provider.keyUrl.isNotEmpty()) {
                    Text(
                        tr(lang, "Get a key: ", "Key मिळवा: ") + provider.keyUrl,
                        color = TextDim,
                        fontSize = 11.sp
                    )
                }
            }
            if (isActive) {
                StatusBadge(tr(lang, "ACTIVE", "सक्रिय"), Neon)
            } else {
                OutlinedButton(onClick = { vm.setProvider(provider.id) }) {
                    Text(tr(lang, "Use", "वापरा"))
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        if (provider.id == "custom") {
            OutlinedTextField(
                value = baseUrl,
                onValueChange = { baseUrl = it },
                label = { Text("Base URL (e.g. https://host/v1)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
        }

        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text("API key") },
            singleLine = true,
            visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth()
        )
        TextButton(onClick = { showKey = !showKey }) {
            Text(
                if (showKey) tr(lang, "Hide key", "Key लपवा")
                else tr(lang, "Show key", "Key दाखवा")
            )
        }

        OutlinedTextField(
            value = model,
            onValueChange = { model = it },
            label = { Text(tr(lang, "Model name", "मॉडेलचे नाव")) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (provider.suggestions.isNotEmpty()) {
            Text(
                tr(lang, "Examples: ", "उदाहरणे: ") + provider.suggestions.joinToString(", "),
                color = TextDim,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(Modifier.height(10.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                vm.saveProvider(provider.id, key, model, baseUrl)
            }) { Text(tr(lang, "Save", "सेव्ह")) }
            OutlinedButton(onClick = {
                vm.saveProvider(provider.id, key, model, baseUrl)
                vm.testProvider(provider.id)
            }) { Text(tr(lang, "Save & test", "सेव्ह आणि तपासा")) }
        }

        val result = state.testResults[provider.id]
        if (result != null) {
            Spacer(Modifier.height(6.dp))
            val ok = result == "OK"
            Text(
                text = if (ok) tr(lang, "Connection works.", "कनेक्शन चालू आहे.") else result,
                color = if (ok) Neon else NeonAmber,
                fontSize = 12.sp
            )
        }
    }
}
