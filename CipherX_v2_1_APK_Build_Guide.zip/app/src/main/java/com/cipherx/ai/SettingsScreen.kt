package com.cipherx.ai

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsScreen(vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    val lang = state.language
    var confirmClear by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ScreenTitle(tr(lang, "Settings", "सेटिंग्ज"))

        NeonCard {
            Text(tr(lang, "Language", "भाषा"), color = Neon, fontSize = 16.sp)
            Text(
                tr(
                    lang,
                    "Changes the app text, voice input language and the voice used for spoken replies.",
                    "ऍपमधील मजकूर, व्हॉइस इनपुटची भाषा आणि बोलून उत्तराचा आवाज बदलतो."
                ),
                color = TextDim,
                fontSize = 12.sp
            )
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (lang == "en") {
                    Button(onClick = { vm.setLanguage("en") }) { Text("English") }
                    OutlinedButton(onClick = { vm.setLanguage("mr") }) { Text("मराठी") }
                } else {
                    OutlinedButton(onClick = { vm.setLanguage("en") }) { Text("English") }
                    Button(onClick = { vm.setLanguage("mr") }) { Text("मराठी") }
                }
            }
        }

        NeonCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(tr(lang, "Speak replies aloud", "उत्तर बोलून ऐकवा"), color = Neon, fontSize = 16.sp)
                    Text(
                        tr(
                            lang,
                            "Uses your phone's text-to-speech. Marathi needs Marathi voice data installed in the phone's speech settings.",
                            "फोनचे text-to-speech वापरते. मराठीसाठी फोनच्या स्पीच सेटिंग्जमध्ये मराठी व्हॉइस डेटा हवा."
                        ),
                        color = TextDim,
                        fontSize = 12.sp
                    )
                }
                Switch(checked = state.speak, onCheckedChange = { vm.setSpeak(it) })
            }
        }

        NeonCard {
            Text(tr(lang, "Security", "सुरक्षा"), color = Neon, fontSize = 16.sp)
            Spacer(Modifier.height(4.dp))
            val encrypted = vm.settingsStore().isEncrypted
            if (encrypted) {
                StatusBadge(tr(lang, "API keys encrypted on this phone", "API keys फोनमध्ये एन्क्रिप्टेड"), Neon)
            } else {
                StatusBadge(
                    tr(lang, "Encrypted storage unavailable — keys saved unencrypted", "एन्क्रिप्टेड स्टोरेज उपलब्ध नाही — keys साध्या स्वरूपात"),
                    NeonAmber
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                tr(
                    lang,
                    "Messages are sent to the AI provider you select, using your own key. Chats are saved only on this phone.",
                    "तुम्ही निवडलेल्या AI प्रदात्याकडे, तुमच्या स्वतःच्या key ने, संदेश पाठवले जातात. चॅट फक्त या फोनमध्ये सेव्ह होतात."
                ),
                color = TextDim,
                fontSize = 12.sp
            )
        }

        NeonCard {
            Text(tr(lang, "Data", "डेटा"), color = Neon, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { confirmClear = true },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed, contentColor = Ink)
            ) {
                Text(tr(lang, "Delete all chats and keys", "सर्व चॅट आणि keys हटवा"))
            }
        }

        NeonCard {
            Text("PAGER-X CIPHERX AI", color = Neon, fontSize = 16.sp)
            Text("Version 2.0 · Phase 1", color = TextDim, fontSize = 12.sp)
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(tr(lang, "Delete everything?", "सर्व काही हटवायचे?")) },
            text = {
                Text(
                    tr(
                        lang,
                        "This removes all saved chats, API keys and settings from this phone. It cannot be undone.",
                        "यामुळे या फोनमधील सर्व चॅट, API keys आणि सेटिंग्ज हटतील. हे परत मिळणार नाही."
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearAllData()
                    confirmClear = false
                }) { Text(tr(lang, "Delete", "हटवा"), color = NeonRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) {
                    Text(tr(lang, "Cancel", "रद्द करा"))
                }
            }
        )
    }
}
