@file:OptIn(ExperimentalMaterial3Api::class)

package com.cipherx.ai

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ChatScreen(vm: ChatViewModel, onOpenModels: () -> Unit) {
    val state by vm.state.collectAsState()
    val lang = state.language
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var voiceProblem by remember { mutableStateOf<String?>(null) }

    val cfg = remember(state.providerId, state.settingsRev) {
        vm.settingsStore().config(state.providerId)
    }

    val lastLength = state.messages.lastOrNull()?.text?.length ?: 0
    LaunchedEffect(state.messages.size, lastLength) {
        val last = state.messages.size - 1
        if (last >= 0) listState.scrollToItem(last)
    }

    val voiceLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val heard = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!heard.isNullOrBlank()) {
                input = if (input.isBlank()) heard else "$input $heard"
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("CipherX", color = Neon, fontSize = 20.sp, style = MaterialTheme.typography.titleLarge)
                Text(
                    "${cfg.provider.name} · ${cfg.model.ifBlank { "—" }}",
                    color = TextDim,
                    fontSize = 11.sp
                )
            }
            TextButton(onClick = { vm.newChat() }) {
                Text(tr(lang, "New chat", "नवीन चॅट"))
            }
        }

        if (state.messages.isEmpty()) {
            EmptyState(
                lang = lang,
                hasKey = cfg.apiKey.isNotBlank(),
                onOpenModels = onOpenModels,
                modifier = Modifier.weight(1f)
            )
        } else {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                itemsIndexed(state.messages) { _, message ->
                    MessageBubble(message)
                }
            }
        }

        state.notice?.let {
            Text(
                text = it,
                color = NeonAmber,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )
        }
        voiceProblem?.let {
            Text(
                text = it,
                color = NeonAmber,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
            )
        }

        InputBar(
            lang = lang,
            value = input,
            onValueChange = { input = it },
            isLoading = state.isLoading,
            onSend = {
                val text = input
                input = ""
                voiceProblem = null
                vm.sendMessage(text)
            },
            onStop = { vm.stop() },
            onMic = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                    )
                    putExtra(
                        RecognizerIntent.EXTRA_LANGUAGE,
                        if (lang == "mr") "mr-IN" else "en-US"
                    )
                }
                try {
                    voiceProblem = null
                    voiceLauncher.launch(intent)
                } catch (e: ActivityNotFoundException) {
                    voiceProblem = tr(
                        lang,
                        "Voice input is not available on this phone.",
                        "या फोनवर व्हॉइस इनपुट उपलब्ध नाही."
                    )
                }
            }
        )
    }

    state.error?.let { message ->
        AlertDialog(
            onDismissRequest = { vm.clearError() },
            title = { Text(tr(lang, "Something went wrong", "काहीतरी चुकले")) },
            text = { Text(message) },
            confirmButton = {
                TextButton(onClick = { vm.clearError() }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { vm.clearError(); onOpenModels() }) {
                    Text(tr(lang, "Open Models", "Models उघडा"))
                }
            }
        )
    }
}

@Composable
private fun EmptyState(
    lang: String,
    hasKey: Boolean,
    onOpenModels: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("PAGER-X CIPHERX AI", color = Neon, fontSize = 20.sp, style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))
        Text(
            text = tr(
                lang,
                "Ask anything. Your chats stay on this phone.",
                "काहीही विचारा. तुमचे चॅट फक्त या फोनमध्येच राहतात."
            ),
            textAlign = TextAlign.Center,
            color = TextDim
        )
        if (!hasKey) {
            Spacer(Modifier.height(16.dp))
            Text(
                text = tr(
                    lang,
                    "No API key yet for the selected model.",
                    "निवडलेल्या मॉडेलसाठी अजून API key नाही."
                ),
                color = NeonAmber,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Button(onClick = onOpenModels) {
                Text(tr(lang, "Add API key", "API key टाका"))
            }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.isUser
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            color = if (isUser) Neon else PanelHigh,
            border = if (isUser) null else BorderStroke(1.dp, NeonDim),
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            modifier = Modifier.widthIn(max = 320.dp)
        ) {
            SelectionContainer {
                Text(
                    text = message.text.ifEmpty { "…" },
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (isUser) Ink else TextMain
                )
            }
        }
    }
}

@Composable
private fun InputBar(
    lang: String,
    value: String,
    onValueChange: (String) -> Unit,
    isLoading: Boolean,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onMic: () -> Unit
) {
    Surface(color = Panel, tonalElevation = 0.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.weight(1f),
                placeholder = { Text(tr(lang, "Ask anything…", "काहीही विचारा…")) },
                maxLines = 4,
                shape = RoundedCornerShape(24.dp)
            )
            Spacer(Modifier.width(6.dp))
            OutlinedButton(
                onClick = onMic,
                enabled = !isLoading,
                contentPadding = PaddingValues(horizontal = 12.dp),
                border = BorderStroke(1.dp, NeonDim)
            ) {
                Text("🎤")
            }
            Spacer(Modifier.width(6.dp))
            if (isLoading) {
                Button(
                    onClick = onStop,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonRed, contentColor = Ink)
                ) {
                    Text(tr(lang, "Stop", "थांबा"))
                }
            } else {
                Button(onClick = onSend, enabled = value.isNotBlank()) {
                    Text(tr(lang, "Send", "पाठवा"))
                }
            }
        }
    }
}
