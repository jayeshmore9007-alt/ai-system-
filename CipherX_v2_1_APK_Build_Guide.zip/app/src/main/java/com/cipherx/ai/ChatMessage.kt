package com.cipherx.ai

/** One turn in the conversation. */
data class ChatMessage(
    val text: String,
    val isUser: Boolean
)
