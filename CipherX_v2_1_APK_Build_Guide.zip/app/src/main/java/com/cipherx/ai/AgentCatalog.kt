package com.cipherx.ai

/** Capability catalogue only. An agent is LIVE only when a real executor is wired and verified. */
enum class AgentState { LIVE, PLANNED, NOT_CONFIGURED }

data class AgentDefinition(
    val id: String,
    val name: String,
    val role: String,
    val detail: String,
    val state: AgentState
)

val cipherAgents = listOf(
    AgentDefinition("cipher-core", "CIPHER CORE", "Central assistant", "Routes user requests through the currently configured AI chat provider. It does not execute device commands.", AgentState.LIVE),
    AgentDefinition("wifi-sentinel", "WIFI SENTINEL", "Network diagnostics", "Permission-aware Android connectivity diagnostics. Detailed Wi-Fi and gateway data require platform permissions and implementation.", AgentState.PLANNED),
    AgentDefinition("device-scanner", "DEVICE SCANNER", "Authorized device discovery", "Discovery for devices on networks and transports explicitly selected by the user.", AgentState.PLANNED),
    AgentDefinition("flipper-agent", "FLIPPER AGENT", "Flipper Zero integration", "Requires a supported USB/Bluetooth transport and a tested device protocol adapter.", AgentState.NOT_CONFIGURED),
    AgentDefinition("esp32-agent", "ESP32 AGENT", "ESP32 device hub", "Requires a configured BLE, Wi-Fi, or USB serial protocol and explicit command allowlist.", AgentState.NOT_CONFIGURED),
    AgentDefinition("pager-x-agent", "PAGER-X AGENT", "Pager diagnostics", "Requires an authenticated Pager-X backend. SSH and shell execution are not exposed by this app.", AgentState.NOT_CONFIGURED),
    AgentDefinition("instagram-agent", "INSTAGRAM AGENT", "Authorized account assistance", "Requires Meta app credentials, approved scopes, and account authorization.", AgentState.NOT_CONFIGURED),
    AgentDefinition("code-master", "CODE MASTER", "Code intelligence", "Can help with code through the central AI chat; repository-aware multi-file tools are not connected.", AgentState.PLANNED),
    AgentDefinition("apk-builder", "APK BUILDER", "Android builds", "Requires a configured CI or EAS build service. No build service is connected.", AgentState.NOT_CONFIGURED),
    AgentDefinition("repair-agent", "REPAIR AGENT", "Application diagnostics", "Can explain errors supplied in chat; automatic project repair is not connected.", AgentState.PLANNED),
    AgentDefinition("research-agent", "RESEARCH AGENT", "Technical research", "Research requires an explicitly configured retrieval or web service.", AgentState.NOT_CONFIGURED),
    AgentDefinition("voice-agent", "VOICE AGENT", "Speech input and output", "Uses Android speech recognition intents and the phone text-to-speech engine.", AgentState.LIVE),
    AgentDefinition("automation-agent", "AUTOMATION AGENT", "Approved workflows", "Workflow editor and execution engine are not implemented.", AgentState.PLANNED),
    AgentDefinition("security-guard", "SECURITY GUARD", "Permissions and audit", "API keys are stored using Android encrypted preferences when available; full audit and role-based access are not implemented.", AgentState.PLANNED),
    AgentDefinition("documentation-agent", "DOCUMENTATION AGENT", "Project documentation", "Documentation drafting is available through central AI chat; project indexing is not connected.", AgentState.PLANNED)
)
