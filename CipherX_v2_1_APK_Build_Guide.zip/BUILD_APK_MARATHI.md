# CIPHERX APK Build (मराठी)

या प्रोजेक्टमध्ये GitHub Actions workflow आधीपासून आहे: `.github/workflows/build-apk.yml`.

## GitHub वरून APK तयार करण्याची पद्धत

1. `CipherX_v2_1_Video_Style_Dashboard.zip` extract करा.
2. संपूर्ण project GitHub repository मध्ये upload/push करा.
3. Repository मध्ये **Actions** tab उघडा.
4. **Build APK** workflow निवडा.
5. **Run workflow** दाबा (किंवा `main`/`master` branch वर push करा).
6. Build पूर्ण झाल्यावर workflow run मधील **Artifacts** विभागातून `CipherX-debug-apk` डाउनलोड करा.
7. ZIP extract करून `app-debug.apk` Android फोनवर install करा.

## महत्त्वाचे
- या वातावरणात Android SDK उपलब्ध नाही आणि Gradle 8.7 download करण्यासाठी नेटवर्क DNS उपलब्ध नाही. त्यामुळे इथे `assembleDebug` पूर्ण होऊ शकले नाही; APK तयार झाल्याचा दावा केलेला नाही.
- GitHub Actions runner वर JDK 17 आणि Gradle dependencies डाउनलोड करून build होईल.
- हा **debug APK** असेल. Play Store/release साठी signing configuration आणि release build वेगळे सेट करावे लागतील.
