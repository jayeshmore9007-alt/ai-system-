import { Router } from "express";
import { z } from "zod";
const router = Router();
const schema = z.object({
  model: z.string().min(1).max(120).optional(),
  messages: z.array(z.object({ role: z.enum(["system", "user", "assistant"]), content: z.string().min(1).max(20000) })).min(1).max(40)
});
router.post("/", async (req, res) => {
  const parsed = schema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid chat payload", details: parsed.error.flatten() });
  const { AI_API_KEY, AI_BASE_URL, AI_MODEL } = process.env;
  if (!AI_API_KEY || !AI_BASE_URL || !AI_MODEL) return res.status(503).json({ error: "AI provider is not configured on the backend." });
  const url = `${AI_BASE_URL.replace(/\/$/, "")}/chat/completions`;
  try {
    const upstream = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: `Bearer ${AI_API_KEY}` },
      body: JSON.stringify({ model: parsed.data.model || AI_MODEL, messages: parsed.data.messages, stream: false })
    });
    const raw = await upstream.text();
    if (!upstream.ok) return res.status(502).json({ error: "AI provider request failed", providerStatus: upstream.status });
    const data = JSON.parse(raw);
    const content = data.choices?.[0]?.message?.content;
    if (typeof content !== "string") return res.status(502).json({ error: "Provider returned an unsupported response." });
    res.json({ content, model: data.model || parsed.data.model || AI_MODEL });
  } catch {
    res.status(502).json({ error: "AI provider could not be reached." });
  }
});
export default router;
