import { Router } from "express";
import { agents } from "../agents.js";
const router = Router();
router.get("/", (_req, res) => res.json({ agents }));
export default router;
