import test from "node:test";
import assert from "node:assert/strict";
import { agents } from "./agents.js";

test("agent catalogue has unique identifiers and explicit status", () => {
  assert.equal(agents.length, 15);
  assert.equal(new Set(agents.map((agent) => agent.id)).size, agents.length);
  for (const agent of agents) assert.ok(["live", "planned", "not_configured"].includes(agent.status));
});
