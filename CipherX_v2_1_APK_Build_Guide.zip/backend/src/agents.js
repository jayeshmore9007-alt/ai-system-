export const agents = [
  ["cipher-core", "CIPHER CORE", "Central assistant", "live"],
  ["wifi-sentinel", "WIFI SENTINEL", "Network diagnostics", "planned"],
  ["device-scanner", "DEVICE SCANNER", "Authorized device discovery", "planned"],
  ["flipper-agent", "FLIPPER AGENT", "Flipper Zero integration", "not_configured"],
  ["esp32-agent", "ESP32 AGENT", "ESP32 device hub", "not_configured"],
  ["pager-x-agent", "PAGER-X AGENT", "Pager diagnostics", "not_configured"],
  ["instagram-agent", "INSTAGRAM AGENT", "Authorized Instagram assistance", "not_configured"],
  ["code-master", "CODE MASTER", "Code intelligence", "planned"],
  ["apk-builder", "APK BUILDER", "Android build service", "not_configured"],
  ["repair-agent", "REPAIR AGENT", "Application diagnostics", "planned"],
  ["research-agent", "RESEARCH AGENT", "Technical research", "not_configured"],
  ["voice-agent", "VOICE AGENT", "Speech input/output", "live"],
  ["automation-agent", "AUTOMATION AGENT", "Approved workflows", "planned"],
  ["security-guard", "SECURITY GUARD", "Permissions and audit", "planned"],
  ["documentation-agent", "DOCUMENTATION AGENT", "Documentation assistance", "planned"]
].map(([id, name, role, status]) => ({ id, name, role, status }));
