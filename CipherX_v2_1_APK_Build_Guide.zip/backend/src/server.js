import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import { requireAppToken } from "./middleware/auth.js";
import agentsRouter from "./routes/agents.js";
import chatRouter from "./routes/chat.js";

const app = express();
app.disable("x-powered-by");
app.use(helmet());
app.use(cors({ origin: false })); // Configure explicit trusted origins if a browser client is added.
app.use(express.json({ limit: "64kb" }));
app.get("/health", (_req, res) => res.json({ status: "ok", service: "cipherx-api", timestamp: new Date().toISOString() }));
app.use("/api", requireAppToken);
app.use("/api/agents", agentsRouter);
app.use("/api/chat", chatRouter);
app.use((err, _req, res, _next) => {
  res.status(500).json({ error: "Internal server error" });
});
const port = Number(process.env.PORT || 8080);
app.listen(port, "0.0.0.0", () => console.log(`CipherX API listening on ${port}`));
