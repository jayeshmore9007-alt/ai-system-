export function requireAppToken(req, res, next) {
  const expected = process.env.CIPHERX_API_TOKEN;
  if (!expected || expected.length < 32) {
    return res.status(503).json({ error: "Backend authentication is not configured." });
  }
  const supplied = req.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!supplied || supplied !== expected) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}
